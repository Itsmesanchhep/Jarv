# JARVIS progress

Confirmed working by user: build, install, Gemini replies, voice.

Written but not yet tested: screen voice control (Accessibility), messaging and calling through WhatsApp, Messenger, Instagram,
direct phone calls (CALL_PHONE), spoken yes/no confirmation in the overlay.

Kept on purpose: confirmation before every send or call; refusal to press payment and delete buttons; never typing into password fields.
Not included: continuous listening, wake word, default-assistant role, file management.
