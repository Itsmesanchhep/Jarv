package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Voice-control engine (like Google's Voice Access). Runs only when the user turns it on in Android's
 * Accessibility settings, and only acts on commands the user speaks. It does not send screen content anywhere.
 */
class JarvisAccessibilityService : AccessibilityService() {

    private var overlay: FrameLayout? = null
    private val numbered = mutableListOf<AccessibilityNodeInfo>()
    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideNumbers() }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        hideNumbers()
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    // ---------- finding the app on screen (not JARVIS's own panel) ----------
    private fun appRoot(): AccessibilityNodeInfo? {
        for (w in windows) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val r = w.root ?: continue
            if (r.packageName?.toString() != packageName) return r
        }
        val r = rootInActiveWindow
        return if (r != null && r.packageName?.toString() != packageName) r else null
    }

    private fun labelOf(n: AccessibilityNodeInfo): String =
        "${n.text ?: ""} ${n.contentDescription ?: ""}".trim()

    private fun clickableAncestor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = n
        var depth = 0
        while (c != null && depth < 8) {
            if (c.isClickable) return c
            c = c.parent
            depth++
        }
        return null
    }

    // ---------- global actions ----------
    fun global(name: String): String {
        val (action, msg) = when (name) {
            "back" -> GLOBAL_ACTION_BACK to "Going back."
            "home" -> GLOBAL_ACTION_HOME to "Going home."
            "recents" -> GLOBAL_ACTION_RECENTS to "Showing recent apps."
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS to "Opening notifications."
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS to "Opening quick settings."
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN to "Locking the screen."
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT to "Taking a screenshot."
            else -> return "I don't know that action."
        }
        return if (performGlobalAction(action)) msg else "Android didn't allow that on this phone."
    }

    // ---------- tapping ----------
    private fun tapAt(x: Float, y: Float, durationMs: Long): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs)).build()
        return dispatchGesture(g, null, null)
    }

    private fun click(n: AccessibilityNodeInfo, long: Boolean): String {
        val label = labelOf(n)
        if (RISKY.containsMatchIn(label)) {
            return "That looks like a payment or delete action. For safety, please tap it yourself."
        }
        val target = clickableAncestor(n)
        val ok = if (target != null) {
            target.performAction(if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            val r = Rect()
            n.getBoundsInScreen(r)
            tapAt(r.exactCenterX(), r.exactCenterY(), if (long) 700 else 50)
        }
        hideNumbers()
        val what = label.ifBlank { "that" }
        return if (ok) (if (long) "Long pressing $what." else "Tapping $what.") else "That didn't work."
    }

    fun tapText(query: String, long: Boolean): String {
        if (query.isBlank()) return "What should I tap?"
        val root = appRoot() ?: return "I can't see an app screen right now."
        val matches = root.findAccessibilityNodeInfosByText(query).filter { it.isVisibleToUser }
        if (matches.isEmpty()) return "I couldn't find \"$query\" on the screen."
        val best = matches.minByOrNull { labelOf(it).length } ?: matches.first()
        return click(best, long)
    }

    fun tapNumber(n: Int): String {
        val node = numbered.getOrNull(n - 1) ?: return "Say show numbers first, then pick a number."
        node.refresh()
        return click(node, false)
    }

    // ---------- scrolling and swiping ----------
    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun walk(x: AccessibilityNodeInfo) {
            if (x.isVisibleToUser && x.isScrollable) {
                val r = Rect()
                x.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) { best = x; bestArea = a }
            }
            for (i in 0 until x.childCount) x.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return best
    }

    fun scroll(dir: String): String {
        val root = appRoot() ?: return "I can't see an app screen right now."
        val action = when (dir) {
            "down" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
            "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id
            "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id
            "right" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id
            else -> return "Which direction should I scroll?"
        }
        val node = findScrollable(root)
        if (node != null && node.performAction(action)) return "Scrolling $dir."
        val finger = when (dir) { "down" -> "up"; "up" -> "down"; "left" -> "right"; else -> "left" }
        return swipe(finger, "Scrolling $dir.")
    }

    fun swipe(dir: String, msg: String = "Swiping $dir."): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "up" -> { p.moveTo(w / 2, h * 0.7f); p.lineTo(w / 2, h * 0.3f) }
            "down" -> { p.moveTo(w / 2, h * 0.3f); p.lineTo(w / 2, h * 0.7f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return "Which direction should I swipe?"
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build()
        return if (dispatchGesture(g, null, null)) msg else "I couldn't swipe."
    }

    // ---------- typing (never into password fields) ----------
    private fun focusedInput(): AccessibilityNodeInfo? = appRoot()?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

    fun typeText(text: String): String {
        if (text.isBlank()) return "What should I type?"
        val f = focusedInput() ?: return "Tap a text field first, then ask me to type."
        if (f.isPassword) return "I won't type into password fields."
        val cur = if (f.isShowingHintText) "" else (f.text?.toString() ?: "")
        val joined = if (cur.isBlank() || cur.endsWith(" ")) cur + text else "$cur $text"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, joined)
        }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed." else "I couldn't type there."
    }

    fun clearText(): String {
        val f = focusedInput() ?: return "Tap a text field first."
        if (f.isPassword) return "I won't change password fields."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Cleared." else "I couldn't clear that."
    }

    fun pressEnter(): String {
        val f = focusedInput() ?: return "Tap a text field first."
        val ok = Build.VERSION.SDK_INT >= 30 &&
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        return if (ok) "Done." else "I couldn't press enter here."
    }

    // ---------- send / call flows inside messaging apps ----------
    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, "JARVIS: $msg", android.widget.Toast.LENGTH_LONG).show()
    }

    private fun firstEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo) {
            if (found != null) return
            if (n.isVisibleToUser && n.isEditable && !n.isPassword) { found = n; return }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return found
    }

    private fun findByLabels(root: AccessibilityNodeInfo, labels: List<String>, exact: Boolean): AccessibilityNodeInfo? {
        for (l in labels) {
            val hits = root.findAccessibilityNodeInfosByText(l).filter { it.isVisibleToUser }
            val pick = if (exact) hits.firstOrNull { labelOf(it).trim().equals(l, ignoreCase = true) } else hits.firstOrNull()
            if (pick != null) return pick
        }
        return null
    }

    private fun clickDirect(n: AccessibilityNodeInfo): Boolean {
        val t = clickableAncestor(n)
        if (t != null) return t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapAt(r.exactCenterX(), r.exactCenterY(), 50)
    }

    /**
     * After JARVIS opens a chat, wait for the app, optionally type the message, then press the button
     * with one of the labels (Send, Voice call...). Only acts inside the named app. Reports with a toast.
     */
    fun runFlow(pkgs: Set<String>, typeText: String?, labels: List<String>, exact: Boolean, okMsg: String, failMsg: String) {
        var tries = 0
        val step = object : Runnable {
            override fun run() {
                tries++
                val root = appRoot()
                if (root != null && root.packageName?.toString() in pkgs) {
                    var ready = typeText == null
                    if (typeText != null) {
                        val field = firstEditable(root)
                        if (field != null) {
                            if (field.text?.toString() != typeText) {
                                val args = Bundle().apply {
                                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, typeText)
                                }
                                field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                            }
                            ready = true
                        }
                    }
                    if (ready) {
                        val btn = findByLabels(root, labels, exact)
                        if (btn != null && clickDirect(btn)) {
                            toast(okMsg)
                            return
                        }
                    }
                }
                if (tries < 14) handler.postDelayed(this, 900) else toast(failMsg)
            }
        }
        handler.postDelayed(step, 2000)
    }

    // ---------- numbered labels, like Voice Access ----------
    fun showNumbers(): String {
        val root = appRoot() ?: return "I can't see an app screen right now."
        hideNumbers()
        val items = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (items.size >= 60) return
            if (n.isVisibleToUser && (n.isClickable || n.isEditable)) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) items.add(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        if (items.isEmpty()) return "I couldn't find anything tappable here."

        val layout = FrameLayout(this)
        items.forEachIndexed { i, n ->
            val r = Rect()
            n.getBoundsInScreen(r)
            val tv = TextView(this).apply {
                text = "${i + 1}"
                setTextColor(Color.BLACK)
                setBackgroundColor(0xFF3DDCFF.toInt())
                textSize = 12f
                setPadding(8, 2, 8, 2)
            }
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = r.left.coerceAtLeast(0)
            lp.topMargin = r.top.coerceAtLeast(0)
            layout.addView(tv, lp)
        }
        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(layout, params)
        overlay = layout
        numbered.addAll(items)
        handler.postDelayed(hideRunnable, 60_000)
        return "Numbers are showing. Say tap and a number."
    }

    fun hideNumbers() {
        handler.removeCallbacks(hideRunnable)
        overlay?.let {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
        numbered.clear()
    }

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null

        /** Buttons JARVIS will not press for you. */
        private val RISKY = Regex(
            "\\b(pay|payment|purchase|buy|order|checkout|send money|transfer|delete|remove|uninstall|erase|reset)\\b",
            RegexOption.IGNORE_CASE
        )
    }
}
