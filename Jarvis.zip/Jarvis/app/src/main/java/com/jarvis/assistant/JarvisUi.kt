package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF03070D)
private val Bg2 = Color(0xFF071526)
private val Panel = Color(0xFF0B1A2C)
private val Cyan = Color(0xFF3DDCFF)
private val Amber = Color(0xFFFFB84D)
private val Mint = Color(0xFF5CF2C0)
private val TextDim = Color(0xFF7C93AB)
private val TextMain = Color(0xFFE8F4FF)

@Composable
fun JarvisApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Bg, surface = Panel,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        val vm: JarvisViewModel = viewModel()
        val context = LocalContext.current
        var tab by remember { mutableIntStateOf(0) }

        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) vm.onMicTapped()
            else vm.notify("I need the microphone permission to hear you. Open Settings to grant it.")
        }
        val onMic: () -> Unit = {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) vm.onMicTapped() else launcher.launch(Manifest.permission.RECORD_AUDIO)
        }

        PermissionHost(vm)

        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().background(Bg).padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("CORE", "LOG", "SETTINGS").forEachIndexed { i, name ->
                        Column(
                            Modifier.clickable { tab = i }.padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(name, color = if (tab == i) Cyan else TextDim, fontSize = 12.sp, letterSpacing = 3.sp)
                            Box(
                                Modifier.padding(top = 4.dp).size(width = 22.dp, height = 2.dp)
                                    .background(if (tab == i) Cyan else Color.Transparent)
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(
                Modifier.padding(padding).fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Bg, Bg2, Bg)))
            ) {
                DotGrid(Modifier.fillMaxSize())
                when (tab) {
                    0 -> HomeScreen(vm, onMic)
                    1 -> LogScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
fun DotGrid(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val step = 30.dp.toPx()
        var y = step / 2
        while (y < size.height) {
            var x = step / 2
            while (x < size.width) {
                drawCircle(Cyan.copy(alpha = 0.07f), 1.2.dp.toPx(), Offset(x, y))
                x += step
            }
            y += step
        }
    }
}

@Composable
fun HomeScreen(vm: JarvisViewModel, onMic: () -> Unit) {
    val label = when {
        vm.paused -> "PAUSED"
        vm.status == Status.LISTENING -> "LISTENING"
        vm.status == Status.THINKING -> "PROCESSING"
        vm.status == Status.SPEAKING -> "SPEAKING"
        else -> "STANDBY"
    }
    val lastUser = vm.messages.lastOrNull { it.fromUser }?.text
    val lastBot = vm.messages.lastOrNull { !it.fromUser }?.text ?: ""
    val accent = when {
        vm.paused -> TextDim
        vm.status == Status.LISTENING -> Mint
        vm.status == Status.THINKING -> Amber
        else -> Cyan
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "J.A.R.V.I.S", color = TextMain, fontSize = 18.sp, letterSpacing = 8.sp,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text("● SYSTEM ONLINE", color = Mint, fontSize = 10.sp, letterSpacing = 3.sp,
            modifier = Modifier.padding(top = 4.dp))

        Orb(vm.status, vm.level, accent, Modifier.fillMaxWidth().height(290.dp).padding(top = 8.dp))

        Text(label, color = accent, fontSize = 13.sp, letterSpacing = 5.sp)
        Waveform(vm.status, vm.level, accent, Modifier.fillMaxWidth(0.7f).height(28.dp).padding(top = 8.dp))

        Column(
            Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (lastUser != null) {
                Text("\u201C$lastUser\u201D", color = TextDim, fontSize = 14.sp, textAlign = TextAlign.Center,
                    fontFamily = FontFamily.Serif)
            }
            Text(lastBot, color = TextMain, fontSize = 17.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp))
        }

        ConfirmCard(vm)

        Row(
            Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(width = 84.dp, height = 40.dp).clickable { vm.togglePause() },
                contentAlignment = Alignment.CenterStart) {
                Text(if (vm.paused) "RESUME" else "PAUSE", color = if (vm.paused) Amber else TextDim,
                    fontSize = 12.sp, letterSpacing = 3.sp)
            }
            Box(
                Modifier.size(78.dp)
                    .background(accent.copy(alpha = if (vm.status == Status.LISTENING) 0.30f else 0.10f), CircleShape)
                    .border(1.5.dp, accent, CircleShape)
                    .clickable { onMic() },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(26.dp)) {
                    val w = size.width
                    val h = size.height
                    drawRoundRect(accent, Offset(w * 0.34f, 0f), Size(w * 0.32f, h * 0.55f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.16f))
                    drawArc(accent, 0f, 180f, false, Offset(w * 0.18f, h * 0.2f), Size(w * 0.64f, h * 0.55f),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
                    drawLine(accent, Offset(w * 0.5f, h * 0.75f), Offset(w * 0.5f, h * 0.95f),
                        strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                }
            }
            Box(Modifier.size(width = 84.dp, height = 40.dp))
        }
    }
}

@Composable
fun Orb(status: Status, level: Float, accent: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val rot by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "rot"
    )
    val pulse by t.animateFloat(
        initialValue = 0.95f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val energy = when (status) {
        Status.LISTENING -> level
        Status.SPEAKING -> 0.55f
        Status.THINKING -> 0.35f
        Status.IDLE -> 0.05f
    }
    val speedMul = if (status == Status.THINKING) 3f else 1f

    Canvas(modifier) {
        val c = center
        val base = size.minDimension / 2f

        // soft glow
        drawCircle(
            brush = Brush.radialGradient(
                listOf(accent.copy(alpha = 0.28f + 0.2f * energy), Color.Transparent),
                center = c, radius = base
            ),
            radius = base, center = c
        )

        // outer tick ring
        val tickR = base * 0.96f
        rotate(rot * speedMul * 0.5f, pivot = c) {
            for (i in 0 until 90) {
                val a = i * 4f * (PI.toFloat() / 180f)
                val long = i % 6 == 0
                val r2 = tickR - (if (long) 10.dp.toPx() else 5.dp.toPx())
                drawLine(
                    accent.copy(alpha = if (long) 0.9f else 0.35f),
                    Offset(c.x + cos(a) * tickR, c.y + sin(a) * tickR),
                    Offset(c.x + cos(a) * r2, c.y + sin(a) * r2),
                    strokeWidth = if (long) 1.6.dp.toPx() else 1.dp.toPx()
                )
            }
        }

        // dashed ring (counter-rotating)
        rotate(-rot * speedMul, pivot = c) {
            drawCircle(
                accent.copy(alpha = 0.5f), base * 0.76f, c,
                style = Stroke(1.2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 14f)))
            )
        }

        // arc segments
        rotate(rot * speedMul * 2f, pivot = c) {
            val r = base * 0.64f
            val st = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
            drawArc(accent, 20f, 70f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = st)
            drawArc(accent, 200f, 70f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = st)
        }
        rotate(-rot * speedMul * 3f, pivot = c) {
            val r = base * 0.52f
            val st = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round)
            drawArc(accent.copy(alpha = 0.7f), 90f, 110f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = st)
            drawArc(accent.copy(alpha = 0.7f), 270f, 110f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = st)
        }

        // core
        val core = base * (0.30f + 0.12f * energy) * pulse
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.9f), accent.copy(alpha = 0.85f), accent.copy(alpha = 0.1f)),
                center = c, radius = core
            ),
            radius = core, center = c
        )
        drawCircle(accent, core, c, style = Stroke(1.5.dp.toPx()))
    }
}

@Composable
fun Waveform(status: Status, level: Float, accent: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "phase"
    )
    val amp = when (status) {
        Status.LISTENING -> 0.15f + level * 0.85f
        Status.SPEAKING -> 0.6f
        Status.THINKING -> 0.25f
        Status.IDLE -> 0.05f
    }
    Canvas(modifier) {
        val bars = 40
        val gap = size.width / bars
        for (i in 0 until bars) {
            val envelope = sin(PI.toFloat() * i / bars) // taper at the edges
            val wave = 0.5f + 0.5f * sin(phase + i * 0.5f)
            val h = size.height * (0.08f + amp * wave * envelope * 0.92f)
            val x = gap * i + gap / 2
            drawLine(
                accent.copy(alpha = 0.85f),
                Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = gap * 0.4f, cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun LogScreen(vm: JarvisViewModel) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text("CONVERSATION LOG", color = Cyan, fontSize = 13.sp, letterSpacing = 4.sp,
            modifier = Modifier.padding(vertical = 18.dp))
        LazyColumn(
            Modifier.fillMaxSize(), state = listState,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.messages) { m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Text(
                        m.text, color = TextMain, fontSize = 15.sp,
                        modifier = Modifier
                            .background(
                                if (m.fromUser) Cyan.copy(alpha = 0.15f) else Panel,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) {
        tick++
        onPauseOrDispose { }
    }
    val micGranted = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    var provider by remember { mutableStateOf(vm.prefs.provider) }
    var geminiKey by remember { mutableStateOf(vm.prefs.geminiKey) }
    var geminiModel by remember { mutableStateOf(vm.prefs.geminiModel) }
    var claudeKey by remember { mutableStateOf(vm.prefs.apiKey) }
    var speak by remember { mutableStateOf(vm.prefs.speakReplies) }
    var rate by remember { mutableStateOf(vm.prefs.speechRate) }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("PERMISSIONS", color = Cyan, fontSize = 13.sp, letterSpacing = 4.sp)
        Column(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Microphone: " + if (micGranted) "granted" else "not granted",
                color = if (micGranted) Mint else Amber)
            Text("Needed so JARVIS can hear you. Audio is only captured while you tap the mic.",
                color = TextDim, fontSize = 13.sp)
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
                )
            }) { Text(if (micGranted) "Review or revoke" else "Grant in system settings") }
        }
        Text("No other permissions are requested yet. Each new feature will ask separately and explain why.",
            color = TextDim, fontSize = 13.sp)

        Text("AI PROVIDER", color = Cyan, fontSize = 13.sp, letterSpacing = 4.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (provider == "gemini") Button(onClick = {}) { Text("Gemini") }
            else OutlinedButton(onClick = { provider = "gemini"; saved = false }) { Text("Gemini") }
            if (provider == "claude") Button(onClick = {}) { Text("Claude") }
            else OutlinedButton(onClick = { provider = "claude"; saved = false }) { Text("Claude") }
        }
        if (provider == "gemini") {
            OutlinedTextField(
                value = geminiKey, onValueChange = { geminiKey = it; saved = false },
                label = { Text("Gemini API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = geminiModel, onValueChange = { geminiModel = it; saved = false },
                label = { Text("Gemini model name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        } else {
            OutlinedTextField(
                value = claudeKey, onValueChange = { claudeKey = it; saved = false },
                label = { Text("Claude API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
        }
        Button(onClick = {
            vm.prefs.provider = provider
            vm.prefs.geminiKey = geminiKey.trim()
            vm.prefs.geminiModel = geminiModel.trim().ifBlank { SecurePrefs.DEFAULT_GEMINI_MODEL }
            vm.prefs.apiKey = claudeKey.trim()
            saved = true
        }) { Text("Save") }
        if (saved) Text("Saved. Keys are stored encrypted on this phone.", color = Mint, fontSize = 13.sp)

        Text("VOICE", color = Cyan, fontSize = 13.sp, letterSpacing = 4.sp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()
        ) {
            Text("Speak replies aloud")
            Switch(checked = speak, onCheckedChange = { speak = it; vm.prefs.speakReplies = it })
        }
        Text("Speaking speed: ${"%.1f".format(rate)}x", color = TextDim)
        Slider(value = rate, onValueChange = { rate = it; vm.prefs.speechRate = it }, valueRange = 0.5f..2.0f)

        VoiceStyleSection(vm)
        QuickAccessSection(vm)
        VoiceControlSection()
        MessagingSection(vm)
        AccessSection()
        MemorySection(vm)
        ActivitySection(vm)
    }
}
