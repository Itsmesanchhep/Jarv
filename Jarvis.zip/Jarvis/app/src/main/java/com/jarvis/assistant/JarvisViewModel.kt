package com.jarvis.assistant

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

enum class Status { IDLE, LISTENING, THINKING, SPEAKING }

data class Msg(val fromUser: Boolean, val text: String)

class PendingAction(val spec: ToolSpec, val args: JSONObject, val prompt: String)

class JarvisViewModel(app: Application) : AndroidViewModel(app), VoiceEngine.Callbacks {

    val prefs = SecurePrefs(app)
    val messages = mutableStateListOf(Msg(false, "JARVIS online. Tap the microphone and speak."))
    val memories = mutableStateListOf<String>()
    val actionLog = mutableStateListOf<String>()

    var status by mutableStateOf(Status.IDLE)
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var paused by mutableStateOf(false)
        private set
    var pending by mutableStateOf<PendingAction?>(null)
        private set
    var permissionRequest by mutableStateOf<String?>(null)
        private set

    private var retry: (() -> Unit)? = null
    private val voice = VoiceEngine(app, this, prefs.voiceName)
    private val router = ToolRouter(onRemember = { addMemory(it) }, onForgetAll = { clearMemories() })
    private val ai: AiProvider = SwitchingProvider(prefs)
    private val history = mutableListOf<ChatMessage>()

    init {
        memories.addAll(prefs.memoryRaw.split("\n").filter { it.isNotBlank() })
        actionLog.addAll(prefs.logRaw.split("\n").filter { it.isNotBlank() })
    }

    // ---------- memory (only what you explicitly ask JARVIS to remember) ----------
    fun addMemory(text: String) {
        memories.add(text.replace("\n", " "))
        while (memories.size > 50) memories.removeAt(0)
        prefs.memoryRaw = memories.joinToString("\n")
    }

    fun deleteMemory(index: Int) {
        if (index in memories.indices) memories.removeAt(index)
        prefs.memoryRaw = memories.joinToString("\n")
    }

    fun clearMemories() {
        memories.clear()
        prefs.memoryRaw = ""
    }

    // ---------- activity history ----------
    private fun logAction(text: String) {
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM d HH:mm"))
        actionLog.add("$stamp  $text")
        while (actionLog.size > 50) actionLog.removeAt(0)
        prefs.logRaw = actionLog.joinToString("\n")
    }

    fun clearActionLog() {
        actionLog.clear()
        prefs.logRaw = ""
    }

    // ---------- controls ----------
    fun onMicTapped() {
        if (paused) {
            messages.add(Msg(false, "JARVIS is paused. Tap Resume first."))
            return
        }
        when (status) {
            Status.LISTENING -> {
                voice.stopListening()
                status = Status.IDLE
            }
            else -> voice.startListening() // also interrupts speech
        }
    }

    fun togglePause() {
        paused = !paused
        if (paused) {
            voice.stopSpeaking()
            voice.stopListening()
            pending = null
            status = Status.IDLE
        }
    }

    fun availableVoices(): List<String> = voice.voiceNames()

    fun selectVoice(name: String) {
        prefs.voiceName = name
        voice.selectVoice(name)
        previewVoice()
    }

    fun previewVoice() {
        voice.speak("Good evening. All systems are online. How may I assist you?", prefs.speechRate, prefs.pitch)
    }

    fun notify(text: String) {
        messages.add(Msg(false, text))
    }

    fun confirmPending(yes: Boolean) {
        val p = pending ?: return
        pending = null
        if (yes) runTool(p.spec, p.args) else reply("Cancelled.")
    }

    fun onPermissionResult(granted: Boolean) {
        val r = retry
        permissionRequest = null
        retry = null
        if (granted) r?.invoke() else reply("Okay. I can't do that without the permission.")
    }

    // ---------- core flow ----------
    private val yesWords = setOf("yes", "yeah", "yep", "confirm", "do it", "go ahead", "sure", "ok", "okay", "yes please")
    private val noWords = setOf("no", "nope", "cancel", "stop", "don't", "never mind", "no thanks")

    private fun handle(text: String) {
        status = Status.THINKING
        val t = text.lowercase().trim(' ', '.', '!', '?')
        val p = pending
        if (p != null) {
            pending = null
            if (t in yesWords) { runTool(p.spec, p.args); return }
            if (t in noWords) { reply("Cancelled."); return }
        }
        val local = router.tryLocal(text)
        if (local != null) {
            val spec = router.find(local.name)
            if (spec != null) { dispatch(spec, local.args); return }
        }
        viewModelScope.launch {
            try {
                history.add(ChatMessage("user", text))
                val raw = ai.chat(history, buildSystemPrompt()).ifBlank { "I have nothing to say to that." }
                val call = router.parse(raw)
                val spec = call?.let { router.find(it.name) }
                if (call != null && spec != null) {
                    history.add(ChatMessage("assistant", call.say.ifBlank { "Done." }))
                    dispatch(spec, call.args)
                } else {
                    history.add(ChatMessage("assistant", raw))
                    reply(raw)
                }
            } catch (e: Exception) {
                if (history.lastOrNull()?.role == "user") history.removeAt(history.size - 1)
                reply("AI error: ${e.message}", spoken = "Sorry, I had a problem. Check the screen for details.")
            }
        }
    }

    private fun dispatch(spec: ToolSpec, args: JSONObject) {
        if (spec.sensitive) {
            val prompt = confirmText(spec, args)
            pending = PendingAction(spec, args, prompt)
            reply("$prompt Say yes, or tap Confirm.", spoken = "$prompt Say yes to confirm.")
        } else {
            runTool(spec, args)
        }
    }

    private fun confirmText(spec: ToolSpec, a: JSONObject): String = when (spec.name) {
        "call" -> "Call ${a.optString("target")}?"
        "message" -> "Send \"${a.optString("message")}\" to ${a.optString("target")} on ${a.optString("app")}?"
        "app_call" -> (if (a.optBoolean("video", false)) "Video call " else "Call ") + "${a.optString("target")} on ${a.optString("app")}?"
        "sms" -> "Prepare a text to ${a.optString("target")} saying \"${a.optString("message")}\"?"
        "calendar_event" -> "Add \"${a.optString("title")}\" at ${a.optString("start")} to your calendar?"
        "do_not_disturb" -> if (a.optBoolean("on", true)) "Turn on Do Not Disturb?" else "Turn off Do Not Disturb?"
        else -> "Run ${spec.name}?"
    }

    private fun runTool(spec: ToolSpec, args: JSONObject) {
        val res = try {
            spec.run(getApplication(), args)
        } catch (e: Exception) {
            ToolResult("That failed: ${e.message}")
        }
        if (res.permission != null) {
            retry = { runTool(spec, args) }
            permissionRequest = res.permission
            reply(res.message)
            return
        }
        logAction("${spec.name} $args")
        reply(res.message)
    }

    private fun buildSystemPrompt(): String {
        val now = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, yyyy-MM-dd HH:mm z"))
        val mem = if (memories.isEmpty()) "" else
            "\nThings the user asked you to remember:\n" + memories.joinToString("\n") { "- $it" }
        return """
            You are JARVIS, a calm, polished British AI butler with dry wit, working as a concise voice assistant on the user's Android phone. Your replies are spoken aloud: use one to three short sentences, no markdown, no lists.
            Current local date and time: $now.$mem

            To act on the phone, reply with ONLY one JSON object and nothing else: {"tool":"<name>","args":{...},"say":"<short sentence>"}
            For anything else, reply in plain text. For weather, news and research, search the web and summarize briefly.
            Never claim you did something on the phone unless you used a tool. If no tool fits, say you can't do that yet.
            The "screen" tool controls whichever app is on screen (tap by visible text, scroll, type, go back or home). You cannot see the screen, so use it only when the user says what to tap or do.
            Use "message" to send through WhatsApp, Messenger, Instagram or SMS, "app_call" to call through those apps, and "call" for ordinary phone calls.
            Resolve relative times like "tomorrow at 7" using the current date and time above.
            Tools:
            ${router.describeTools()}
        """.trimIndent()
    }

    private fun reply(text: String, spoken: String = text) {
        messages.add(Msg(false, text))
        if (prefs.speakReplies && !paused) {
            status = Status.SPEAKING
            voice.speak(spoken, prefs.speechRate, prefs.pitch)
        } else {
            status = Status.IDLE
        }
    }

    // ---------- VoiceEngine callbacks ----------
    override fun onListening() { status = Status.LISTENING }

    override fun onLevel(level: Float) { this.level = level }

    override fun onResult(text: String) {
        level = 0f
        messages.add(Msg(true, text))
        handle(text)
    }

    override fun onVoiceError(message: String) {
        level = 0f
        status = Status.IDLE
        messages.add(Msg(false, message))
    }

    override fun onSpeakingStart() { status = Status.SPEAKING }

    override fun onSpeakingDone() {
        if (status == Status.SPEAKING) status = Status.IDLE
    }

    override fun onCleared() {
        voice.shutdown()
    }
}
