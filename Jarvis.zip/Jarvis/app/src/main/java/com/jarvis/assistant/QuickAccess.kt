package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

/** Persistent notification so you can speak to JARVIS from any screen. */
object QuickAccess {
    private const val CHANNEL = "jarvis_quick"
    private const val ID = 1001

    fun show(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "JARVIS quick access", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, VoiceOverlayActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icon = Icon.createWithResource(ctx, R.drawable.ic_stat_jarvis)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("JARVIS")
            .setContentText("Tap to speak")
            .setOngoing(true)
            .setContentIntent(pi)
            .addAction(Notification.Action.Builder(icon, "Speak", pi).build())
            .build()
        nm.notify(ID, n)
    }

    fun hide(ctx: Context) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
    }
}
