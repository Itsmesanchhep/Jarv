package com.jarvis.assistant

import android.service.notification.NotificationListenerService

/** Lets JARVIS read your current notifications aloud, only when you ask and only after you grant access. */
class JarvisNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }

    companion object {
        @Volatile var instance: JarvisNotificationListener? = null
    }
}
