package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Messaging and calling through WhatsApp, Messenger and Instagram. Needs JARVIS voice control (Accessibility) turned on. */
object AppMessaging {
    private val WA = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val MESSENGER = setOf("com.facebook.orca")
    private val INSTAGRAM = setOf("com.instagram.android")

    private fun needAccess(c: Context): ToolResult {
        try {
            c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
        return ToolResult("This needs JARVIS voice control turned on in Accessibility settings. I opened it.")
    }

    /** WhatsApp needs the full international number without plus or zeros. */
    private fun waNumber(c: Context, raw: String): String? {
        val d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.removePrefix("00")
        val cc = SecurePrefs(c).countryCode
        if (cc.isBlank()) return null
        if (d.startsWith(cc) && d.length > 10) return d
        return cc + d.removePrefix("0")
    }

    private fun open(c: Context, uri: String, pkgs: List<String>): Boolean {
        for (p in pkgs) {
            try {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(p).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (_: Exception) {}
        }
        return false
    }

    private const val NO_CC = "I need your country code to reach that number. Set it in Settings under Messaging, or save the contact with a plus sign."

    fun message(c: Context, app: String, target: String, message: String): ToolResult {
        if (message.isBlank()) return ToolResult("What should the message say?")
        val a = app.lowercase().trim()
        if (a == "sms" || a == "text" || a == "messages") return PhoneTools.sms(c, target, message)
        val svc = JarvisAccessibilityService.instance ?: return needAccess(c)
        when (a) {
            "whatsapp" -> {
                val (num, err) = PhoneTools.resolve(c, target)
                if (err != null) return err
                val n = waNumber(c, num ?: return ToolResult("I couldn't find a number for $target.")) ?: return ToolResult(NO_CC)
                val uri = "https://wa.me/$n?text=" + Uri.encode(message)
                if (!open(c, uri, listOf("com.whatsapp", "com.whatsapp.w4b"))) return ToolResult("I couldn't open WhatsApp. Is it installed?")
                svc.runFlow(WA, null, listOf("send"), true,
                    "Message sent to $target on WhatsApp.", "I couldn't find WhatsApp's send button. Please tap it yourself.")
                return ToolResult("Opening WhatsApp to message $target.")
            }
            "instagram", "messenger" -> {
                val insta = a == "instagram"
                val user = target.trim().removePrefix("@").replace(" ", "")
                if (user.isBlank()) return ToolResult("I need the exact username.")
                val uri = if (insta) "https://ig.me/m/$user" else "https://m.me/$user"
                val pkgs = if (insta) INSTAGRAM else MESSENGER
                val name = if (insta) "Instagram" else "Messenger"
                if (!open(c, uri, pkgs.toList())) return ToolResult("I couldn't open $name. Is it installed?")
                svc.runFlow(pkgs, message, listOf("send"), true,
                    "Message sent to $user on $name.", "I couldn't finish sending on $name. Please check the chat.")
                return ToolResult("Opening $name to message $user.")
            }
            else -> return ToolResult("I can message through WhatsApp, Messenger, Instagram or SMS.")
        }
    }

    fun call(c: Context, app: String, target: String, video: Boolean): ToolResult {
        val a = app.lowercase().trim()
        if (a == "" || a == "phone" || a == "sim" || a == "call") return PhoneTools.call(c, target)
        val svc = JarvisAccessibilityService.instance ?: return needAccess(c)
        val labels = if (video) listOf("video call", "video chat") else listOf("voice call", "audio call")
        when (a) {
            "whatsapp" -> {
                val (num, err) = PhoneTools.resolve(c, target)
                if (err != null) return err
                val n = waNumber(c, num ?: return ToolResult("I couldn't find a number for $target.")) ?: return ToolResult(NO_CC)
                if (!open(c, "https://wa.me/$n", listOf("com.whatsapp", "com.whatsapp.w4b"))) return ToolResult("I couldn't open WhatsApp. Is it installed?")
                svc.runFlow(WA, null, labels, false,
                    "Calling $target on WhatsApp.", "I couldn't find the call button. Please tap it yourself.")
                return ToolResult("Opening WhatsApp to call $target.")
            }
            "instagram", "messenger" -> {
                val insta = a == "instagram"
                val user = target.trim().removePrefix("@").replace(" ", "")
                if (user.isBlank()) return ToolResult("I need the exact username.")
                val uri = if (insta) "https://ig.me/m/$user" else "https://m.me/$user"
                val pkgs = if (insta) INSTAGRAM else MESSENGER
                val name = if (insta) "Instagram" else "Messenger"
                if (!open(c, uri, pkgs.toList())) return ToolResult("I couldn't open $name. Is it installed?")
                svc.runFlow(pkgs, null, labels, false,
                    "Calling $user on $name.", "I couldn't find the call button on $name. Please tap it yourself.")
                return ToolResult("Opening $name to call $user.")
            }
            else -> return ToolResult("I can call through the phone, WhatsApp, Messenger or Instagram.")
        }
    }
}
