package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceEngine(private val context: Context, private val cb: Callbacks, private val preferredVoice: String = "") {

    interface Callbacks {
        fun onListening()
        fun onLevel(level: Float)
        fun onResult(text: String)
        fun onVoiceError(message: String)
        fun onSpeakingStart()
        fun onSpeakingDone()
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                if (preferredVoice.isNotBlank()) selectVoice(preferredVoice)
                ttsReady = true
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                main.post { cb.onSpeakingStart() }
            }

            override fun onDone(utteranceId: String?) {
                main.post { cb.onSpeakingDone() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { cb.onSpeakingDone() }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                main.post { cb.onSpeakingDone() }
            }
        })
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            cb.onVoiceError("Speech recognition is not available. Install or update the Google app, then try again.")
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { cb.onListening() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                cb.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { cb.onVoiceError(errorText(error)) }
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) cb.onVoiceError("I didn't catch that. Tap the mic and try again.")
                else cb.onResult(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        r.startListening(intent)
    }

    fun stopListening() {
        recognizer?.cancel()
    }

    /** English voices installed on this phone, British ones first. */
    fun voiceNames(): List<String> = try {
        tts?.voices
            ?.filter { it.locale.language == "en" }
            ?.sortedWith(compareBy({ it.locale.country != "GB" }, { it.name }))
            ?.map { it.name } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun selectVoice(name: String) {
        try {
            tts?.voices?.firstOrNull { it.name == name }?.let { tts?.voice = it }
        } catch (_: Exception) {}
    }

    fun speak(text: String, rate: Float, pitch: Float = 1.0f) {
        if (!ttsReady) {
            cb.onSpeakingDone()
            return
        }
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun shutdown() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }

    private fun errorText(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            "I didn't catch that. Tap the mic and try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            "Microphone permission is missing. Open the Permissions tab."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Speech recognition needs a network connection right now."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again."
        SpeechRecognizer.ERROR_AUDIO -> "Audio error. Check your microphone."
        else -> "Speech recognition error (code $code)."
    }
}
