package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect

private val XPanel = Color(0xFF0B1A2C)
private val XCyan = Color(0xFF3DDCFF)
private val XText = Color(0xFFE8F4FF)
private val XDim = Color(0xFF7C93AB)
private val XMint = Color(0xFF5CF2C0)
private val XAmber = Color(0xFFFFB84D)

fun accentFor(status: Status, paused: Boolean): Color = when {
    paused -> XDim
    status == Status.LISTENING -> XMint
    status == Status.THINKING -> XAmber
    else -> XCyan
}

/** Asks for a runtime permission when a tool needs one (contacts, etc.), then retries the command. */
@Composable
fun PermissionHost(vm: JarvisViewModel) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.onPermissionResult(it) }
    val req = vm.permissionRequest
    LaunchedEffect(req) { if (req != null) launcher.launch(req) }
}

@Composable
fun ConfirmCard(vm: JarvisViewModel) {
    val p = vm.pending ?: return
    Column(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).background(XPanel, RoundedCornerShape(12.dp)).padding(12.dp)
    ) {
        Text(p.prompt, color = XText, fontSize = 14.sp)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.confirmPending(true) }) { Text("Confirm") }
            OutlinedButton(onClick = { vm.confirmPending(false) }) { Text("Cancel") }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = XCyan, fontSize = 13.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun QuickAccessSection(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(vm.prefs.quickAccess) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { vm.prefs.quickAccess = true; on = true; QuickAccess.show(ctx) }
    }
    SectionTitle("USE JARVIS FROM ANY SCREEN")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Quick-access notification", color = XText)
        Switch(checked = on, onCheckedChange = { want ->
            if (want) {
                val needs = Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                if (needs) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else { vm.prefs.quickAccess = true; on = true; QuickAccess.show(ctx) }
            } else {
                vm.prefs.quickAccess = false; on = false; QuickAccess.hide(ctx)
            }
        })
    }
    Text(
        "Shows a notification with a Speak button. Tap it from any app and JARVIS listens in a small overlay. " +
            "You can also add the JARVIS tile: swipe down twice, tap the edit (pencil) icon, and drag JARVIS into your active tiles.",
        color = XDim, fontSize = 13.sp
    )
}

@Composable
fun AccessSection() {
    val ctx = LocalContext.current
    fun open(intent: Intent) {
        try { ctx.startActivity(intent) } catch (_: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    SectionTitle("OPTIONAL ACCESS")
    Text("Each one is optional, off by default, and can be revoked in Android settings at any time.", color = XDim, fontSize = 13.sp)

    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Notification access", color = XText)
        Text("Lets JARVIS read your notifications aloud when you ask. The text stays on your phone and is never sent to the AI.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("Open settings") }
    }
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Modify system settings", color = XText)
        Text("Needed only to change screen brightness by voice.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = {
            open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        }) { Text("Open settings") }
    }
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Do Not Disturb access", color = XText)
        Text("Needed only to turn Do Not Disturb on or off by voice.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) { Text("Open settings") }
    }
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Honor battery settings", color = XText)
        Text("Honor may close JARVIS in the background. In Settings > Apps > App launch, set JARVIS to manage manually and allow background activity.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery optimization") }
    }
    Text("Contacts permission is requested only when you ask JARVIS to call or text someone by name.", color = XDim, fontSize = 13.sp)
}

@Composable
fun MemorySection(vm: JarvisViewModel) {
    SectionTitle("MEMORY")
    Text(
        "Only things you ask JARVIS to remember (say \"remember that...\"). They are stored encrypted on this phone and sent to the AI as context with your questions.",
        color = XDim, fontSize = 13.sp
    )
    if (vm.memories.isEmpty()) Text("Nothing saved.", color = XDim, fontSize = 13.sp)
    vm.memories.forEachIndexed { i, m ->
        Row(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(10.dp)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(m, color = XText, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("  ✕", color = XAmber, modifier = Modifier.clickable { vm.deleteMemory(i) }.padding(8.dp))
        }
    }
    if (vm.memories.isNotEmpty()) OutlinedButton(onClick = { vm.clearMemories() }) { Text("Delete all memory") }
}

@Composable
fun ActivitySection(vm: JarvisViewModel) {
    SectionTitle("ACTIVITY HISTORY")
    if (vm.actionLog.isEmpty()) Text("No phone actions yet.", color = XDim, fontSize = 13.sp)
    vm.actionLog.takeLast(15).reversed().forEach {
        Text(it, color = XDim, fontSize = 12.sp)
    }
    if (vm.actionLog.isNotEmpty()) OutlinedButton(onClick = { vm.clearActionLog() }) { Text("Clear history") }
}

@Composable
fun VoiceControlSection() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) {
        tick++
        onPauseOrDispose { }
    }
    val on = remember(tick) { JarvisAccessibilityService.instance != null }
    fun open(intent: Intent) {
        try { ctx.startActivity(intent) } catch (_: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    SectionTitle("VOICE CONTROL (SCREEN ACCESS)")
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Status: " + if (on) "ON" else "OFF", color = if (on) XMint else XAmber)
        Text(
            "Lets JARVIS tap, scroll, type and navigate other apps by voice, like Google Voice Access. It uses Android's Accessibility service. " +
                "Commands run on this phone and your screen is not sent to the AI. JARVIS never types into password fields and refuses payment and delete buttons.",
            color = XDim, fontSize = 13.sp
        )
        Text(
            "Setup: 1) Tap App info, then the ⋮ menu at the top right, then Allow restricted settings (needed for apps installed outside the Play Store). " +
                "2) Tap Open Accessibility settings, find JARVIS voice control under Installed or Downloaded apps, turn it on and accept the warning.",
            color = XDim, fontSize = 13.sp
        )
        OutlinedButton(onClick = {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))
        }) { Text("App info") }
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Open Accessibility settings") }
        Text(
            "To use it: tap the Speak notification or the JARVIS tile, then say one command. Try: go back, go home, scroll down, tap Settings, " +
                "show numbers (then: tap 5), type hello, open notifications, take a screenshot, lock screen.",
            color = XDim, fontSize = 13.sp
        )
    }
}

@Composable
fun MessagingSection(vm: JarvisViewModel) {
    var cc by remember { mutableStateOf(vm.prefs.countryCode) }
    SectionTitle("MESSAGING AND CALLS")
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Say things like \"message Sam on WhatsApp saying I'm late\" or \"call Mom on WhatsApp\". JARVIS always reads back who and what, " +
                "and waits for you to say yes or tap Confirm before sending or calling. WhatsApp and calls by name need Contacts permission (asked when first needed). " +
                "Instagram and Messenger need the exact username. Sending through these apps needs Voice control turned on.",
            color = XDim, fontSize = 13.sp
        )
        OutlinedTextField(
            value = cc, onValueChange = { cc = it.filter { ch -> ch.isDigit() }; vm.prefs.countryCode = cc },
            label = { Text("Your country code, e.g. 977 or 1") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Text("Used for WhatsApp numbers saved without a plus sign.", color = XDim, fontSize = 12.sp)
    }
}

@Composable
fun VoiceStyleSection(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var pitch by remember { mutableStateOf(vm.prefs.pitch) }
    var selected by remember { mutableStateOf(vm.prefs.voiceName) }
    var voices by remember { mutableStateOf(vm.availableVoices()) }
    SectionTitle("JARVIS VOICE")
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "For a deep, calm British male voice: pick a voice below and tap it to hear it, then lower the pitch. " +
                "British voices are listed first. If the list is short, install or update Speech Services by Google and download the English (United Kingdom) voices.",
            color = XDim, fontSize = 13.sp
        )
        Text("Pitch: ${"%.2f".format(pitch)} (lower is deeper)", color = XText)
        androidx.compose.material3.Slider(
            value = pitch, onValueChange = { pitch = it; vm.prefs.pitch = it }, valueRange = 0.5f..1.2f
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.previewVoice() }) { Text("Test voice") }
            OutlinedButton(onClick = { voices = vm.availableVoices() }) { Text("Refresh list") }
        }
        OutlinedButton(onClick = {
            try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (_: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }) { Text("Open text-to-speech settings") }
        if (voices.isEmpty()) Text("No voices found yet. Tap Refresh list.", color = XDim, fontSize = 13.sp)
        voices.take(40).forEach { name ->
            Text(
                (if (name == selected) "● " else "○ ") + name,
                color = if (name == selected) XCyan else XText, fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().clickable { selected = name; vm.selectVoice(name) }.padding(vertical = 8.dp)
            )
        }
    }
}
