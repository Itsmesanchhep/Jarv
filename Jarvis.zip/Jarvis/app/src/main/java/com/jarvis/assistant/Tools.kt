package com.jarvis.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/** Every device action is its own small tool. */
object AppLauncherTool {
    fun run(context: Context, requested: String): String {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(query, 0)
        val name = requested.trim().lowercase()
        if (name.isBlank()) return "Which app should I open?"

        val labelled = apps.map { it to it.loadLabel(pm).toString().lowercase() }
        val match = labelled.firstOrNull { it.second == name }
            ?: labelled.firstOrNull { it.second.startsWith(name) }
            ?: labelled.firstOrNull { it.second.contains(name) }
            ?: return "I couldn't find an app called $requested."

        val launch = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName)
            ?: return "I found ${match.second} but couldn't launch it."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return "Opening ${match.first.loadLabel(pm)}."
    }
}

object FlashlightTool {
    fun run(context: Context, on: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return "This device has no flashlight."
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't control the flashlight: ${e.message}"
        }
    }
}

object DeviceInfoTool {
    fun battery(context: Context): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = if (bm.isCharging) " and charging" else ""
        return "Battery is at $pct percent$charging."
    }

    fun time(): String =
        "It's " + LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a")) + "."
}

/** Phone-control tools. Each one uses official Android APIs and per-feature permissions. */
object PhoneTools {
    private fun launch(c: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    private fun attempt(c: Context, intent: Intent, ok: String): ToolResult = try {
        launch(c, intent); ToolResult(ok)
    } catch (e: Exception) {
        ToolResult("I couldn't do that: ${e.message}")
    }

    fun alarm(c: Context, h: Int, m: Int, label: String): ToolResult {
        if (h !in 0..23 || m !in 0..59) return ToolResult("I need a valid time for the alarm.")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return attempt(c, i, "I asked your clock app to set an alarm for %02d:%02d.".format(h, m))
    }

    fun timer(c: Context, seconds: Int, label: String): ToolResult {
        if (seconds <= 0) return ToolResult("I need a duration for the timer.")
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return attempt(c, i, "I asked your clock app to start a timer for ${seconds / 60} minutes ${seconds % 60} seconds.")
    }

    fun volume(c: Context, action: String, percent: Int): ToolResult {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return when (action) {
            "up" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); ToolResult("Volume up.") }
            "down" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); ToolResult("Volume down.") }
            "mute" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); ToolResult("Muted.") }
            "max" -> { am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI); ToolResult("Volume at maximum.") }
            "set" -> {
                val v = (percent.coerceIn(0, 100) * max / 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
                ToolResult("Volume set to $percent percent.")
            }
            else -> ToolResult("I didn't understand that volume command.")
        }
    }

    fun brightness(c: Context, percent: Int): ToolResult {
        if (!Settings.System.canWrite(c)) {
            val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))
            try { launch(c, i) } catch (_: Exception) {}
            return ToolResult("I need the Modify system settings permission for brightness. I opened that page. Enable it for JARVIS, then ask again.")
        }
        return try {
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (percent.coerceIn(1, 100) * 255 / 100))
            ToolResult("Brightness set to $percent percent.")
        } catch (e: Exception) {
            ToolResult("I couldn't change the brightness: ${e.message}")
        }
    }

    fun doNotDisturb(c: Context, on: Boolean): ToolResult {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            try { launch(c, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (_: Exception) {}
            return ToolResult("I need Do Not Disturb access. I opened that page. Enable it for JARVIS, then ask again.")
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return ToolResult(if (on) "Do Not Disturb is on." else "Do Not Disturb is off.")
    }

    fun openSettings(c: Context, target: String): ToolResult {
        val action = when (target.lowercase()) {
            "wifi", "internet", "network" -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return attempt(c, Intent(action), "Opening $target settings. Android requires you to flip the switch yourself.")
    }

    fun resolve(c: Context, target: String): Pair<String?, ToolResult?> {
        val digits = target.filter { it.isDigit() || it == '+' }
        if (digits.length >= 5 && target.none { it.isLetter() }) return digits to null
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null to ToolResult("I need permission to read your contacts to find $target.", Manifest.permission.READ_CONTACTS)
        }
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        c.contentResolver.query(
            uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$target%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) to null }
        return null to ToolResult("I couldn't find $target in your contacts.")
    }

    fun call(c: Context, target: String): ToolResult {
        val (num, err) = resolve(c, target)
        if (err != null) return err
        val n = num ?: return ToolResult("I couldn't find a number for $target.")
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return ToolResult("I need permission to place calls for you.", Manifest.permission.CALL_PHONE)
        }
        return attempt(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))), "Calling $target.")
    }

    fun sms(c: Context, target: String, message: String): ToolResult {
        val (num, err) = resolve(c, target)
        if (err != null) return err
        val n = num ?: return ToolResult("I couldn't find a number for $target.")
        return attempt(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", message),
            "I've prepared the text to $target. Press send in your messages app.")
    }

    fun calendar(c: Context, title: String, start: String, end: String, desc: String): ToolResult {
        return try {
            val zone = ZoneId.systemDefault()
            val begin = LocalDateTime.parse(start).atZone(zone).toInstant().toEpochMilli()
            val endMs = if (end.isBlank()) begin + 3_600_000L
            else LocalDateTime.parse(end).atZone(zone).toInstant().toEpochMilli()
            val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.Events.DESCRIPTION, desc)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMs)
            attempt(c, i, "Opening your calendar with the event filled in. Tap Save to confirm.")
        } catch (e: Exception) {
            ToolResult("I couldn't read that date and time: ${e.message}")
        }
    }

    /** Read aloud on this phone only. Notification text is never sent to the AI. */
    fun readNotifications(c: Context): ToolResult {
        if (!NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)) {
            try { launch(c, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Exception) {}
            return ToolResult("I need notification access. I opened that page. Enable it for JARVIS, then ask again.")
        }
        val svc = JarvisNotificationListener.instance
            ?: return ToolResult("Notification access is on but not connected yet. Try again in a moment.")
        val pm = c.packageManager
        val items = try {
            svc.activeNotifications.filter { it.packageName != c.packageName }.take(5).mapNotNull { sbn ->
                val ex = sbn.notification.extras
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                if (title.isBlank() && text.isBlank()) null else {
                    @Suppress("DEPRECATION")
                    val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() }
                    catch (e: Exception) { sbn.packageName }
                    "$app: $title $text".trim()
                }
            }
        } catch (e: Exception) { emptyList() }
        return if (items.isEmpty()) ToolResult("You have no notifications.")
        else ToolResult("You have ${items.size} recent notifications. " + items.joinToString(". "))
    }
}

object ScreenTool {
    fun run(c: Context, a: JSONObject): ToolResult {
        val svc = JarvisAccessibilityService.instance
        if (svc == null) {
            try {
                c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
            return ToolResult("Voice control is not turned on. I opened Accessibility settings. Turn on JARVIS voice control there.")
        }
        val target = a.optString("target")
        val msg = when (a.optString("action")) {
            "back", "home", "recents", "notifications", "quick_settings", "lock", "screenshot" -> svc.global(a.optString("action"))
            "scroll" -> svc.scroll(target)
            "swipe" -> svc.swipe(target)
            "tap" -> svc.tapText(target, false)
            "long_press" -> svc.tapText(target, true)
            "tap_number" -> svc.tapNumber(a.optInt("number", 0))
            "show_numbers" -> svc.showNumbers()
            "hide_numbers" -> { svc.hideNumbers(); "Numbers hidden." }
            "type" -> svc.typeText(a.optString("text"))
            "clear_text" -> svc.clearText()
            "enter" -> svc.pressEnter()
            else -> "I don't know that screen action."
        }
        return ToolResult(msg)
    }
}
